package J05020;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s= new Scanner(System.in);
        int n= s.nextInt();
        s.nextLine();
        Sinhvien[] sv= new Sinhvien[n];
        for(int i=0;i<n;i++){
            String id =s.nextLine();
            String name =s.nextLine();
            String grade=s.nextLine();
            String email= s.nextLine();
            sv[i]= new Sinhvien(id,name,grade,email);
        }
        int Q=s.nextInt();
        s.nextLine();
        while (Q-->0){
            String lop=s.nextLine();
            System.out.println("DANH SACH SINH VIEN LOP "+lop+":");
            for(Sinhvien i:sv){
                if(i.getGrade().equals(lop))
                    System.out.println(i);
            }
        }

    }
}
