package DsSinhVien2;

import java.text.ParseException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws ParseException {
        Scanner s= new Scanner(System.in);
        int t= s.nextInt();
        s.nextLine();
        SinhVIen [] sinhVIens=new SinhVIen[t];
        for(int i=0;i<t;i++){
            String name=s.nextLine();
            String lop=s.next();
            s.nextLine();
            String ngaysinh=s.nextLine();
            float gpa=s.nextFloat();
            s.nextLine();
            sinhVIens[i]=new SinhVIen(name,lop,ngaysinh,gpa);
        }
        for (int i=0;i<t;i++){
            System.out.println(sinhVIens[i]);
        }
    }
}
