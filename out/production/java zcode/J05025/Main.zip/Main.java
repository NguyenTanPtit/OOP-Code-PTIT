package J05025;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s= new Scanner(System.in);
        int n= s.nextInt();
        s.nextLine();
        Giangvien [] gv = new Giangvien[n];
        for(int i=0;i<n;i++){
            int id=i+1;
            String name = s.nextLine();
            String major=s.nextLine();
            gv[i]=new Giangvien(id,name,major);
        }
        Arrays.sort(gv);
        for(Giangvien i:gv){
            System.out.println(i);
        }
    }
}
