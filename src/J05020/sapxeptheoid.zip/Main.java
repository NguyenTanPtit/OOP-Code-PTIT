package J05020;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s= new Scanner(System.in);
        Sinhvien[] sv= new Sinhvien[10000];
        int i=0;
        while (s.hasNext()) {
            String id = s.nextLine();
            String name = s.nextLine();
            String grade = s.nextLine();
            String email = s.nextLine();
            sv[i] = new Sinhvien(id, name, grade, email);
            i++;
        }
        Arrays.sort(sv,0,i);
        for(int k=0;k<i;k++){
            System.out.println(sv[k]);
        }
    }
}
