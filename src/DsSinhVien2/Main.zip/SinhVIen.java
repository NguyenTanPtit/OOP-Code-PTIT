package DsSinhVien2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

public class SinhVIen {
    private static int  ma=1;
    private String name;
    private String lop;
    private Date birthday;
    private float gpa;

    public SinhVIen() {
    }

    public SinhVIen(String name, String lop, String birthday, float gpa) throws ParseException {
        this.name = name;
        this.lop = lop;
        this.birthday = new SimpleDateFormat("dd/MM/yyyy").parse(birthday);
        this.gpa = gpa;
    }

    private String convertMsv() {
        StringBuilder res = new StringBuilder(Integer.toString(ma));
        while(res.length() < 3)
            res.insert(0, "0");
        ma ++;
        return res.toString();
    }
    private String chuanhoa(){
        StringBuilder s= new StringBuilder();
        StringTokenizer s1=new StringTokenizer(name.toLowerCase());
        while (s1.hasMoreTokens()){
            String str = s1.nextToken();
            s.append(Character.toUpperCase(str.charAt(0)));
            for(int i=1;i<str.length();i++){
                s.append(str.charAt(i));
            }
            s.append(" ");
        }

        return s.toString().trim();
    }
    @Override
    public String toString() {
        return "B20DCCN"+convertMsv()+" "+chuanhoa()+" "+lop+" "+new SimpleDateFormat("dd/MM/yyyy").format(birthday)+" "+String.format("%.2f",gpa);
    }
}
